// for local testing, you might want to set this
export const SERVER_URL = ""