#! /bin/sh

cd /ctf
python -W ignore angry-girlfriend.py
